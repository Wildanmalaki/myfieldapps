import 'package:flutter/material.dart';
import '../database/database_helper.dart';
import '../models/event_model.dart';

class CreateEventPage extends StatefulWidget {
  @override
  State<CreateEventPage> createState() => _CreateEventPageState();
}

class _CreateEventPageState extends State<CreateEventPage> {

  final title = TextEditingController();
  final sport = TextEditingController();
  final location = TextEditingController();
  final date = TextEditingController();
  final time = TextEditingController();
  final players = TextEditingController();

  saveEvent() async {

    EventModel event = EventModel(
      title: title.text,
      sport: sport.text,
      location: location.text,
      date: date.text,
      time: time.text,
      players: int.parse(players.text),
    );

    await DatabaseHelper.instance.insertEvent(event);

    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5),
      appBar: AppBar(title: Text("Create Event")),

      body: Padding(
        padding: EdgeInsets.all(16),
        child: ListView(
          children: [

            TextField(controller: title, decoration: InputDecoration(labelText: "Event Title")),
            TextField(controller: sport, decoration: InputDecoration(labelText: "Sport")),
            TextField(controller: location, decoration: InputDecoration(labelText: "Location")),
            TextField(controller: date, decoration: InputDecoration(labelText: "Date")),
            TextField(controller: time, decoration: InputDecoration(labelText: "Time")),
            TextField(controller: players, decoration: InputDecoration(labelText: "Players Needed")),

            SizedBox(height: 20),

            ElevatedButton(
              onPressed: saveEvent,
              child: Text("Create Event"),
            )

          ],
        ),
      ),
    );
  }
}