import 'package:flutter/material.dart';
import '../database/database_helper.dart';
import '../models/event_model.dart';
import 'create_event_page.dart';

class CommunityPage extends StatefulWidget {
  const CommunityPage({super.key});

  @override
  State<CommunityPage> createState() => _CommunityPageState();
}

class _CommunityPageState extends State<CommunityPage> {

  List<EventModel> events = [];

  Future loadEvents() async {
    final data = await DatabaseHelper.instance.getEvents();

    setState(() {
      events = data;
    });
  }

  @override
  void initState() {
    super.initState();
    loadEvents();
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      backgroundColor: Color.fromARGB(255, 255, 255, 255),
      

      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: const Text(
          "Explore Events",
          style: TextStyle(color: Colors.black),
        ),
        actions: const [
          Icon(Icons.search, color: Colors.black),
          SizedBox(width: 10),
          Icon(Icons.notifications_none, color: Colors.black),
          SizedBox(width: 10)
        ],
      ),

      body: Column(
        children: [

          const SizedBox(height: 10),

          // CATEGORY
          SizedBox(
            height: 45,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 15),
              children: [

                categoryChip("All Sports", true),
                categoryChip("Soccer", false),
                categoryChip("Basketball", false),
                categoryChip("Futsal", false),

              ],
            ),
          ),

          const SizedBox(height: 10),

          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: const [
                Text(
                  "Community Matches",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text("View Map", style: TextStyle(color: Colors.blue))
              ],
            ),
          ),

          const SizedBox(height: 10),

          Expanded(
            child: events.isEmpty
                ? const Center(child: Text("Belum ada event"))
                : ListView.builder(
                    itemCount: events.length,
                    itemBuilder: (context, index) {

                      final event = events[index];

                      return eventCard(event);

                    },
                  ),
          )
        ],
      ),

      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.orange,
        child: const Icon(Icons.add),
        onPressed: () async {

          await Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => CreateEventPage(),
            ),
          );

          loadEvents();
        },
      ),
    );
  }

  // CATEGORY CHIP
  Widget categoryChip(String text, bool active) {

    return Container(
      margin: const EdgeInsets.only(right: 10),
      child: Chip(
        label: Text(text),
        backgroundColor: active ? Colors.blue : Colors.white,
        labelStyle: TextStyle(
          color: active ? Colors.white : Colors.black,
        ),
      ),
    );
  }

  // EVENT CARD UI
  Widget eventCard(EventModel event) {

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            blurRadius: 8,
            color: Colors.grey.shade300,
          )
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [

          // IMAGE
          ClipRRect(
            borderRadius: const BorderRadius.vertical(
              top: Radius.circular(16),
            ),
            child: Image.asset(
              "assets/soccer.jpg",
              height: 150,
              width: double.infinity,
              fit: BoxFit.cover,
            ),
          ),

          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [

                Text(
                  event.title,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),

                const SizedBox(height: 6),

                Text(
                  "${event.sport}",
                  style: const TextStyle(
                    color: Colors.grey,
                  ),
                ),

                const SizedBox(height: 10),

                Row(
                  children: [

                    const Icon(Icons.calendar_today, size: 16, color: Colors.orange),
                    const SizedBox(width: 5),

                    Text("${event.date} • ${event.time}"),

                  ],
                ),

                const SizedBox(height: 6),

                Row(
                  children: [

                    const Icon(Icons.location_on, size: 16, color: Colors.red),
                    const SizedBox(width: 5),

                    Text(event.location),

                  ],
                ),

                const SizedBox(height: 12),

                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [

                    Text(
                      "Players Needed: ${event.players}",
                      style: const TextStyle(
                        fontWeight: FontWeight.w500,
                      ),
                    ),

                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.orange,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                      ),
                      onPressed: () {},
                      child: const Text("Join"),
                    )

                  ],
                )

              ],
            ),
          )
        ],
      ),
    );
  }
}